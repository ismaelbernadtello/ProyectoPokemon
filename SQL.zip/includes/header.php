<html>
<head>
	<meta charset="utf-8">
	<title>Proyecto PHP - Ismael Bernad Tello</title>
	<link rel="stylesheet" type="text/css" href="css/estiloHeader.css"> 
	<link rel="icon" type="image/png" href="images/favicon.png"/>
</head>
<body>
	<nav>
		<h1>BDDT Pokemon - Ismael Bernad Tello</h1>
		<ul>
			<li class="opcionesMenu"><a href="index.php">Inicio</a></li>
			<li class="opcionesMenu"><a href="movimientos.php">Movimientos</a></li>
			<li class="opcionesMenu"><a href="pokedex.php">Pokedex</a></li>
			<li class="opcionesMenu"><a href="formularioAnyadirPokemon.php">Añadir Pokemon</a></li>
			<li class="opcionesMenu"><a href="modificarPokemon.php">Modificar Pokemon</a></li>
			<li class="opcionesMenu"><a href="borrarPokemon.php">Borrar Pokemon</a></li>
		</ul>
	</nav>
</body>
</html>