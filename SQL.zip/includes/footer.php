<!-- Propósito: Pie de página de la página web. -->
	<footer>
	<link rel="stylesheet" type="text/css" href="css/estiloFooter.css"> 
		<p class="textoFooter">&copy; Ismael Bernad Tello 1ºH 2023
		<a href="https://github.com/ismaelbernadtello">Github: https://github.com/ismaelbernadtello</a></p>
	</footer>
