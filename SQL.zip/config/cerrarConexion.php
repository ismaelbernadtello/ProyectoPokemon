<?php
mysqli_close($mysqli);//cierro la conexión una vez realizada la consulta
?>