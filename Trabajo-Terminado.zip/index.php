<?php
include_once 'includes/header.php'; //Incluyo el archivo header.php para que aparezca en la página web, 
                                    // solo lo incluyo una vez si ya está incluido no lo vuelve a incluir
?>

<link rel="stylesheet" type="text/css" href="css/estiloIndex.css"> 
<!-- Contenido de la página principal inspirado en Pokémon -->
<video class="fondoVideo" src="images/fondoLoop.mp4" alt="fondo principal de la página" autoplay loop muted></video>


<?php
include_once 'includes/footer.php';//Incluyo el archivo footer.php para que aparezca en la página web, 
                                   // solo lo incluyo una vez si ya está incluido no lo vuelve a incluir
?>
